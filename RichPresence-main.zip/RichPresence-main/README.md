# RichPresence
Rich Presence for FiveM's server. By !Mac_gor Ziomall_#9999

Poradnik w wersji polskiej znajduje się na https://discord.gg/wE5yJvKc8A - #Rich-Presence
