fx_version "cerulean"
game "gta5"
author "Macgor"
description "Rich Presence"

client_script "client.lua"

lua54 "yes"